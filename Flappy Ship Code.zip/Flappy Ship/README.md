# defold-flappy-bird
flappy bird game made in defold
https://d954mas.github.io/defold-flappy-bird/
![2017-05-09_17-31-04](https://cloud.githubusercontent.com/assets/2655263/25856106/aa0385e0-34dd-11e7-8e2f-1350d8a741f9.png)
